package main;
import java.awt.Color;

public class Balloon {
	
	public String letter;
	public Color color;
	int x;
	int y;
	boolean isSpecial= false;
	long time;
	int tmr = 1;
	int speed;
	public Balloon() {
		// TODO Auto-generated constructor stub
	}
	
	public void setTime() {
		this.tmr = 11;
		this.time = System.currentTimeMillis();
	}

}
