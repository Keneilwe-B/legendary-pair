package main;
import javax.sound.sampled.Clip;
import javax.sound.sampled.AudioSystem;

import java.net.URL;

import javax.sound.sampled.AudioInputStream;

public class Sound {
	Clip lisa;
	URL soundURL[] = new URL[5]; 
	
	public Sound() {
		soundURL[0] = getClass().getResource("/luniko.wav");
		soundURL[1] = getClass().getResource("/phelile.wav");
		soundURL[2] = getClass().getResource("/Pop_balloon.wav");
		soundURL[3] = getClass().getResource("/clock_ticking_LT-.wav");
		
	}
	public void setFile(int i) {
		try{
			AudioInputStream ais = AudioSystem.getAudioInputStream(soundURL[i]);
			lisa = AudioSystem.getClip();
			lisa.open(ais);
		}catch(Exception e){
			
		}
	}public void play() {
		lisa.start();
	}public void loop() {
		lisa.loop(lisa.LOOP_CONTINUOUSLY);
		
	}public void stop() {
		lisa.stop();
	}
	

}
