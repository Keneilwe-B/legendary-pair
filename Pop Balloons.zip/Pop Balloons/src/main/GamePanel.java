package main;
import java.awt.Color;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.Timer;

import event.Listener;


public class GamePanel extends JPanel implements ActionListener{
	
	private Color colour ;
	private String letter;
	private Random rand = new Random(); 
	private ArrayList<Balloon> balloonArray= new ArrayList<>();
	private int y = 0;
	private int missed=0, hit= 0;
	private Timer time = new Timer(50,this);
	private Timer BalloonTime;
	private boolean gameover = false;
	public int num_balloon = 0;
	private BufferedImage img,timer;
	private Sound sound = new Sound();
	private int accelerator= 0;
	
	
	public GamePanel() {
		setFocusable(true);
		addKeyListener(new Listener(this));
		random_Alphabets();
		BalloonTime = new Timer(rand.nextInt(200,500), new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            balloons(); 
	        
	        }
	    });
		time.start();
		BalloonTime.start();
		playMusic(0);
		sprites();
	}
	
	public Color random_Colour() {
		int red = rand.nextInt(10,250);
		int green = rand.nextInt(10,250);
		int blue =rand.nextInt(10,250);
		return new Color(red,green,blue);
	}
	
	public String random_Alphabets() {
		num_balloon++;
		String[] alphabets = new String[] {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
		this.letter = alphabets[rand.nextInt(alphabets.length)];
		return letter;
	}
	
	
	public void balloons() {
		
		Balloon balloon = new Balloon();
		int prev = 0;
		for(int i = 0;i<rand.nextInt(5,10);i++) {
			
			balloon.letter = random_Alphabets();
			int x_num = rand.nextInt(750);
			if(prev > x_num-50 && prev < x_num+50) {
				x_num = rand.nextInt(750);
			}
			prev = x_num;
			
			balloon.x = x_num;
			balloon.y = 0;
			
			if(rand.nextInt(20)== 15) { // 5 %chance of getting a special balloon
				balloon.isSpecial = true;
				balloon.setTime();
				balloon.color = new Color(0,0,0);
				balloon.speed = 5;
			}else{
				balloon.isSpecial = false;
				balloon.color = random_Colour();
				balloon.speed = 3;
			}
		}
		
		balloonArray.add(balloon);
	}
	
	public void gameOver() {
		
		if(missed >5 || gameover) {
			SwingUtilities.invokeLater(() -> {
	            playSE(1);
	        });
			time.stop();
			BalloonTime.stop();
			gameover = true;
		}else {
			repaint();
		}
	}
	
	public void playMusic(int k) {
		sound.setFile(k);
		sound.play();
		sound.loop();
	}
	
	public void stopMusic() {
		sound.stop();
	}
	
	public void playSE(int k) {
		sound.setFile(k);
		sound.play();
	}
	
	public void hit(String keycode) {
		for (int i = 0; i < balloonArray.size(); i++) {
			
			if(balloonArray.get(i).letter.equals(keycode) && !gameover) {
				playSE(2);
				hit++;
				balloonArray.remove(balloonArray.get(i));
			}
		}
		
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
	
		g.drawImage(img, 0, 0,getWidth(),getHeight() ,null);
		loop(g);
		displayScore(g);
	}
	public void displayScore(Graphics g) {
	    g.setColor(Color.BLACK);
	    g.setFont(new Font("Arial", Font.BOLD, 24)); 
	    g.drawString("Score: " + hit, 10, 30); 
	    g.drawString("Missed: " + missed, 140, 30); 
	    if(gameover) {
	    	g.drawString("Gameover", getWidth()/2, getHeight()/2); 
	    }
	}
	public void loop(Graphics g) {
		
		for(int count= 0;count<balloonArray.size();count++) {
			letter = balloonArray.get(count).letter;
			int x = balloonArray.get(count).x;
			int y = balloonArray.get(count).y;
			colour = balloonArray.get(count).color;
			g.setColor(colour);
			g.fillOval(x, y, 50, 50);
			int letterX = x+ (50 - g.getFontMetrics().stringWidth(letter))/2;
			int letterY = 10+(50 - g.getFontMetrics().getHeight())/2;
			g.setColor(Color.WHITE);
			g.drawString(letter, letterX,letterY+y);
			
			if(balloonArray.get(count).isSpecial) {
				int now = balloonArray.get(count).tmr;
				long time = balloonArray.get(count).time;
				if(System.currentTimeMillis() - balloonArray.get(count).time>=500) {
					now--;
					playSE(3);
					balloonArray.get(count).tmr = now;
					balloonArray.get(count).time = System.currentTimeMillis();
				}
				g.setColor(Color.RED);
				g.drawImage(timer.getSubimage(95*now, 0, 95, 100),x,letterY+y-50,30,30,null);
				g.drawString(Integer.toString(now), letterX,letterY+y-15);
			}
			
		}
	}
	
	public void sprites() {
		try {
			
			//img = ImageIO.read(getClass().getResourceAsStream("/Balloon_pop.jpg"));
			img = ImageIO.read(getClass().getResourceAsStream("/backGround1.png"));
	        timer = ImageIO.read(getClass().getResourceAsStream("/balloonCountDown.png"));
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		int updateY = 0;
		for(int i = 0; i<balloonArray.size(); i++) {
			updateY = balloonArray.get(i).y+balloonArray.get(i).speed ;
			if(hit == 25*accelerator) {
				updateY += accelerator;
				accelerator++;
			}
			
			if((balloonArray.get(i).isSpecial && updateY > getHeight()) || balloonArray.get(i).tmr == 0) {
				gameover = true;
			}
			if(updateY > getHeight()) {
				missed++;
	
				balloonArray.remove(balloonArray.get(i));
				i--;
			}else {
				balloonArray.get(i).y = updateY;
			}
		}
		gameOver();
		
		}
	
}
