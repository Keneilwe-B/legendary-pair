package main;
import javax.swing.*;
import event.Listener;

public class GameWindow extends JFrame{
	
	JFrame jf = new JFrame();
	public int Screen_Width = 800;
	public int Screen_Height = 600;
	public GameWindow(GamePanel gp){
		
		
		jf.setSize(Screen_Width,Screen_Height);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setResizable(false);
		jf.add(gp);
		jf.requestFocus();
		jf.setVisible(true);
	}
	
	
}
