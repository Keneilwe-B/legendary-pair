package event;

import java.awt.event.KeyEvent;


import java.awt.event.KeyListener;
import main.GamePanel;

public class Listener implements KeyListener {
	
	GamePanel gp ;
	public Listener(GamePanel gp) {
		this.gp = gp;
		
	}
	


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		gp.hit(Character.toString(e.getKeyChar()).toUpperCase());
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
